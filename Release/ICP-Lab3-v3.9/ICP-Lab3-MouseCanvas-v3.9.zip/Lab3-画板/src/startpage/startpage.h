#pragma once

void showStartPage();